
public class EndGameState implements State{
	public void drawBoard(GameController gc)
	{
		//check which player wins here.
		System.out.println("done");
	}
}
