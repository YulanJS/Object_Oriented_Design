
public class Player2SetUpState implements State{
	public void drawBoard(GameController gc)
	{
//		PlayerScreen player2Screen = new PlayerScreen(gc.getPlayer2(), true, gc.getPlayer1());
//		gc.getPlayer2Screen().showScreen();
		gc.getPlayer2Screen().selfScreenClicked();
//		PlayerScreen player2Screen = new PlayerScreen(gc.getPlayer2(), true, gc.getPlayer1());
//		gc.getPlayer2Screen().showScreen();
		gc.setState(new Player1ToPlay());
//		Player1ToPlay s = new Player1ToPlay();
//		s.drawBoard(gc);
//		gc.getState().drawBoard(gc);
	}
}
