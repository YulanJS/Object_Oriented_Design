
public class Player1ToPlay implements State {
	public void drawBoard(GameController gc)
	{
		gc.getPlayer1Screen().attackScreenClicked();
		gc.setState(new Player2ToPlay());
	}
}
