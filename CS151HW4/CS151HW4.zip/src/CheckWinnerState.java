
public class CheckWinnerState {
	
}
