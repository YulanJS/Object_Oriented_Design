import javax.swing.event.*;
import java.util.ArrayList;
import java.util.Iterator;
public class BattleShip {
	public static void main(String[] args) {
		
//		PlayerScreen player1 = new PlayerScreen("Player1", true);
//		player1.getSelfLocation();
////		PlayerScreen player2 = new PlayerScreen("Player2", true);
		GameController gameController = new GameController();
		gameController.update();
//		gameController.getPlayer1Screen().selfScreenClicked();
//		ShipBoard shipBoard = new ShipBoard("Player1");
//		ChangeListener listener = new
//		ChangeListener()
//		{
//			public void stateChanged(ChangeEvent event)
//			{
//				player1.setShipBoard(shipBoard);
//				player1.rebuildFrame(shipBoard);
//			}
//		};
//		shipBoard.addChangeListener(listener);
		
		
	}
}