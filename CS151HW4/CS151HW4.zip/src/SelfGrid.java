import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

/**
 * Represents the player's own grid
 */
// extends BattleGrid
public class SelfGrid extends BattleGrid {
//	private Point selfGridLocation;
	// private PlayerData playerData;
	public final int OCCUPIED = 6;//a cell from a ship occupies this position.
	public SelfGrid() {
		 super();
//		 selfGridLocation = this.getLocationOnScreen();
//		 double x = this.getLocationOnScreen().getX();
//		 double y = this.getLocationOnScreen().getY();
//		 System.out.println(x);
//		 System.out.println(y);
		// playerData = new PlayerData(name);
	}

	public void redraw(Player player)
	{
		this.removeAll();
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JPanel self = new JPanel();
		self.setLayout(new GridLayout(0, 10));
		int[][] positions = player.getPlayerGrid();
		self.setLayout(new GridLayout(0, 10));
		JPanel cell;
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if(positions[i][j] == OCCUPIED)
				{
					//6 to represent ship there.
					cell = new JPanel();
					cell.setBackground(Color.MAGENTA);
					cell.setBorder(BorderFactory.createLineBorder(Color.white, 1));
					cell.setPreferredSize(new Dimension(20, 20)); 
				}
				else
				{
					cell = getCell();
				}
				self.add(cell);
			}
			this.add(self);
		}
	}
	
//	public void action(ShipBoard shipBoard)
//	{
//		//can I know the event poisition without drawing selfGrid? I just want to get poisition on screen...
//		///which cell is the source, does it matter?
//		this.removeAll();
//		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
//		JPanel self = new JPanel();
//		for (int i = 0; i < 10; i++) {
//			for (int j = 0; j < 10; j++) {
//				JPanel cell = getCell();
//				cell.addMouseListener(new MouseListener() {
//					public void mouseClicked(MouseEvent event) {
//						Object source = event.getSource();
//						// event.getSource doesn't work in the PlayerScreen class, WHY???
//						// encapsulation? no more know who's source?
//						if (source instanceof JPanel) {
//							JPanel cell = (JPanel) source;
//							// Here, must use JPanel cell = ...
//							// cannot directly use cell... WHY???
//							// source should be able to detect its own position!!! search for it!!!
//							// change view coordinates into board coordinates!!!
////							cell.setBackground(Color.GREEN);
//							
//							//event.getX() is the event position inside the small cell...
//					
//							 int x = event.getXOnScreen();
//							 int y = event.getYOnScreen();
//							 System.out.println(x);
//							 System.out.println(y);
//							 //to get the correct coordinate for placeAShip() to use,
//							 //I need to get the screen position of this selfGrid...
//							 Coordinate shipBoardCoordinate = new Coordinate(y / 20, x / 20);
//							 shipBoard.placeAShip(shipBoardCoordinate, 3);
//						}
//					}
//					
//					public void mouseEntered(MouseEvent arg0) {}
//					public void mouseExited(MouseEvent arg0) {}
//					public void mousePressed(MouseEvent arg0) {}
//					public void mouseReleased(MouseEvent arg0) {}
//				});
//			}
//		}
//	}

	
//	
//	public void drawBoard(ShipBoard shipBoard) {
//		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
//		JPanel self = new JPanel();
//		self.setLayout(new GridLayout(0, 10));
//		int[][] positions = shipBoard.getPositions();
//		for (int i = 0; i < 10; i++) {
//			for (int j = 0; j < 10; j++) {
//				JPanel cell = new JPanel();
//				if (positions[i][j] == 1) {
//					cell.setBackground(Color.MAGENTA);
//					cell.setBorder(BorderFactory.createLineBorder(Color.yellow, 1));
//					cell.setPreferredSize(new Dimension(20, 20)); // for demo purposes onl
//				} else {
//					cell = getCell();
//				}
//			}
//		}
//	}
	
	@Override
	protected JPanel getCell() {
		// getCell()...gets new JPanel...
		JPanel panel = new JPanel();
		panel.setBackground(Color.black);
		panel.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		panel.setPreferredSize(new Dimension(20, 20)); // for demo purposes onl
		return panel;
	}
	
//	 public static MouseListener createMouseListener()
//	 {
//		 return new MouseListener(){
//			 public void mouseClicked(MouseEvent event) {
//						Object source = event.getSource();
//						// event.getSource doesn't work in the PlayerScreen class, WHY???
//						// encapsulation? no more know who's source?
////						if (source instanceof JPanel) {
//						JPanel cell = (JPanel) source;
//							// Here, must use JPanel cell = ...
//							// cannot directly use cell... WHY???
//							// source should be able to detect its own position!!! search for it!!!
//							// change view coordinates into board coordinates!!!
////							cell.setBackground(Color.GREEN);
//							
//							//event.getX() is the event position inside the small cell...
//					
//						 int x = event.getXOnScreen();
//						 int y = event.getYOnScreen();
//						 System.out.println(x);
//						 System.out.println(y);
//						 convertCoordinate(x, y);
////							 Coordinate shipBoardCoordinate = new Coordinate(y / 20, x / 20);
////							 shipBoard.placeAShip(shipBoardCoordinate, 3);
//					}
//					
//				public void mouseEntered(MouseEvent arg0) {}
//				public void mouseExited(MouseEvent arg0) {}
//				public void mousePressed(MouseEvent arg0) {}
//				public void mouseReleased(MouseEvent arg0) {}
//			};
//	 }
	 
	 public Coordinate convertCoordinate(int i, int j)
	 {
		 return new Coordinate(100 - i, 100 - j);
	 }
}