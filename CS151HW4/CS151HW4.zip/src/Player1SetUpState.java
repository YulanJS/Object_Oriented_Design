
public class Player1SetUpState implements State{
	
	public void drawBoard(GameController gc)
	{
		gc.getPlayer1Screen().selfScreenClicked();
		gc.setState(new Player2SetUpState());
//		gc.getState().drawBoard(gc);
	}
}
