
public class Player2ToPlay implements State{
	public void drawBoard(GameController gc)
	{
		gc.getPlayer2Screen().attackScreenClicked();
//		PlayerScreen player1Screen = new PlayerScreen(gc.getPlayer1(), true, gc.getPlayer2());
//		gc.getPlayer2Screen().showScreen();
//		player1Screen.attackScreenClicked();
//		Player1ToPlay s = new Player1ToPlay();
//		s.drawBoard(gc);
		gc.setState((State)new EndGameState());
		
	}
}
