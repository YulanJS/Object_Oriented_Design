import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public abstract class BattleGrid extends JPanel {
	public BattleGrid() {
		// shipBoard = new ShipBoard("player1");
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JPanel self = new JPanel();
		self.setLayout(new GridLayout(0, 10));
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				JPanel cell = getCell();
				self.add(cell);
			}
			this.add(self);
		}
		// Problem: ActionListener is undefined for the type JPanel.
		// cell.addActionListener(new ActionListener()
		// {
		// public void actionPerformed(ActionEvent event)
		// {
		// cell = (JPanel)event.getSource();
		// cell.setBackground(Color.yellow);
		// }
		// });
	}
	
	protected abstract JPanel getCell();
	
	// public void drawBoard(ShipBoard shipBoard)
	// {
	// this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	// JPanel self = new JPanel();
	// self.setLayout(new GridLayout(0, 10));
	// for (int i = 0; i < 10; i++) {
	// for (int j = 0; j < 10; j++) {
	// JPanel cell = getCell();
	// cell.addMouseListener(new
	// MouseListener()
	// {
	// public void mouseClicked(MouseEvent event) {
	// Object source = event.getSource();
	// //event.getSource doesn't work in the PlayerScreen class, WHY???
	// //encapsulation? no more know who's source?
	// if (source instanceof JPanel) {
	// JPanel cell = (JPanel) source;
	// // Here, must use JPanel cell = ...
	// //cannot directly use cell... WHY???
	// //source should be able to detect its own position!!! search for it!!!
	// //change view coordinates into board coordinates!!!
	// Coordinate c = new Coordinate(i,j);
	// Ship ship = new Ship(c, 3);
	// if(shipBoard.placeAShip(c, 3))
	// {
	// cell.setBackground(Color.yellow);
	// }
	// }
	// }
	// public void mouseEntered(MouseEvent arg0) {}
	// public void mouseExited(MouseEvent arg0) {}
	// public void mousePressed(MouseEvent arg0) {}
	// public void mouseReleased(MouseEvent arg0) {}
	// });
	// this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	// }
	// this.add(self);
	// }
}