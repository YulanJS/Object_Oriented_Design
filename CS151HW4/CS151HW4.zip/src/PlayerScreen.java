import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class PlayerScreen extends JFrame {
	private SelfGrid selfGrid;
	private AttackGrid attackGrid;
	private Player self;
	private Player other;
	private JButton next;
	private boolean visible;
	//for a screen for player1, it has attackGrid, needs to check the info of player2 
	//to see whether it hits or not.
	//View needs the int[][] positions from Model to draw...
	
	//on player1's screen, only player1 info goes onto selfGrid.
	//
	public PlayerScreen(Player self, boolean show, Player other) {
		super(self.getName());
		this.self = self;
		this.other = other;
		this.setLayout(new BorderLayout());
		selfGrid = new SelfGrid();//What is name doing in self Grid?
		// selfGrid.redraw();
		this.add(selfGrid, BorderLayout.EAST);
		attackGrid = new AttackGrid();
		this.add(attackGrid, BorderLayout.WEST);
		this.add(new JLabel(self.getName()), BorderLayout.NORTH);
		next = new JButton("next");
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hideScreen();
			}
		});
		
		this.add(next, BorderLayout.CENTER);
		
		//add the south JPanel here
		
		
		this.pack();
		this.setVisible(show);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	// I can get the screen location of the mouse click here...
	public void selfScreenClicked() {
		this.showScreen();
		selfGrid.addMouseListener(new MouseListener() {
			public void mouseClicked(MouseEvent event) {
				Object source = event.getSource();
				// if the MouseListener is for the whole selfGrid...it will return the relative
				// position on the grid
//				if(source instanceof SelfGrid) //can detect whether selfGrid or attackGrid is clicked.
//				{
				int x = event.getX() /20; //20 is the size of the small cell in selfGrid
				int y = event.getY() /20;
				System.out.println(x);
				System.out.println(y);
				Coordinate c = new Coordinate(y, x); //screen position and ship board position need to be switched.
				selfModelAction(c);
			}
			public void mouseEntered(MouseEvent arg0) {}
			public void mouseExited(MouseEvent arg0) {}
			public void mousePressed(MouseEvent arg0) {}
			public void mouseReleased(MouseEvent arg0) {}	
		});
	}
	
	public void attackScreenClicked() {
//		this.showScreen();
		attackGrid.addMouseListener(new MouseListener() {
			public void mouseClicked(MouseEvent event) {
				Object source = event.getSource();
				// if the MouseListener is for the whole selfGrid...it will return the relative
				// position on the grid
//				if(source instanceof SelfGrid) //can detect whether selfGrid or attackGrid is clicked.
//				{
				int x = event.getX() /20; //20 is the size of the small cell in selfGrid
				int y = event.getY() /20;
//				System.out.println(x);
//				System.out.println(y);
				Coordinate c = new Coordinate(y, x); //screen position and ship board position need to be switched.
				attackModelAction(c);
			}
			public void mouseEntered(MouseEvent arg0) {}
			public void mouseExited(MouseEvent arg0) {}
			public void mousePressed(MouseEvent arg0) {}
			public void mouseReleased(MouseEvent arg0) {}	
		});
	}
	
	
	public void selfModelAction(Coordinate c)
	{
		//pull it out separately... because each time, getSelfLocation is the same for the self grid...
		//different state, different model action
		int i = 0;
		self.placeAShip(c, 3);
		selfGrid.redraw(self);	//here says selfGrid... //pass the Player self
		this.add(selfGrid, BorderLayout.EAST);
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void attackModelAction(Coordinate c)
	{
		other.fireAt(c);
		attackGrid.redraw(other);	//here says selfGrid...
		this.add(attackGrid, BorderLayout.WEST);
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	// public void placeShips(String name, boolean show)
	// {
	//// selfGrid.getClicked(shipBoard);
	// ChangeListener listener = new
	// ChangeListener()
	// {
	// public void stateChanged(ChangeEvent event)
	// {
	// selfGrid.redraw(shipBoard);
	// }
	// };
	// this.add(selfGrid, BorderLayout.EAST);
	// this.pack();
	// this.setVisible(true);
	// this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// }
	
	public void hideScreen() {
		this.setVisible(false);
	}
	
	public void showScreen() {
		this.setVisible(true);
	}
	
	public void nextClicked()
	{
		
	}
}
