
public interface State {
	public abstract void drawBoard(GameController gc);
}
