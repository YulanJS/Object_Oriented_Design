import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

/**
Represents the player's own grid
*/
public class AttackGrid extends BattleGrid {
	public final int MISS = 1;
	public final int HIT = 2;
	public final int DESTROY = 3;
	
    public AttackGrid() {
        super();
        
    }
    
    //attackGrid only shows hit or not, change one small cell. All ships are placed in selfGrid.
    public void redraw(Player player)
	{
		this.removeAll();
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JPanel self = new JPanel();
		self.setLayout(new GridLayout(0, 10));
		int[][] positions = player.getPlayerGrid();
		self.setLayout(new GridLayout(0, 10));
		JPanel cell;
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if(positions[i][j] == MISS)
				{
					//1 for miss
					cell = new JPanel();
					cell.setBackground(Color.RED);
					cell.setBorder(BorderFactory.createLineBorder(Color.white, 1));
					cell.setPreferredSize(new Dimension(20, 20)); 
					self.add(cell);
				}
				else if(positions[i][j] == HIT || positions[i][j] == DESTROY)
				{
					//2 for hit // 3 for destroy
					cell = new JPanel();
					cell.setBackground(Color.GREEN);
					cell.setBorder(BorderFactory.createLineBorder(Color.white, 1));
					cell.setPreferredSize(new Dimension(20, 20)); 
					self.add(cell);
				}
				else {
					cell = new JPanel();
					cell = getCell();
					self.add(cell);
				}
			}
			this.add(self);
		}
	}
    
     @Override
    protected JPanel getCell()
    {
        JPanel panel = new JPanel();
        panel.setBackground(Color.white);
        panel.setBorder(BorderFactory.createLineBorder(Color.red, 1));
        panel.setPreferredSize(new Dimension(20, 20)); // for demo purposes only

        return panel;
    }
}