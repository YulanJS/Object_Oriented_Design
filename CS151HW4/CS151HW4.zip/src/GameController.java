import java.util.*;
import javax.swing.event.*;

public class GameController{
	private final String PLAYER1 = "player1";
	private final String PLAYER2 = "player2";
	
	
	private Player player1;
	private Player player2;
	private PlayerScreen player1Screen;
	private PlayerScreen player2Screen;
	private State state;
//	private ChangeListener listener;
	public GameController()
	{
		player1 = new Player("PLAYER1");
		player2 = new Player("PLAYER2");
		player1Screen = new PlayerScreen(player1, true, player2);
		player2Screen = new PlayerScreen(player2, false, player1);
//		player2Screen.hideScreen();
	
		
		state = new Player1SetUpState();
		//if not adding the listener to the attribute,then null pointer exception...
		//may be not local variable...so when need to use...some problems???
//		shipBoard.addChangeListener(listener);
	}
//	
	public Player getPlayer1()
	{
		return player1;
	}
	
	public Player getPlayer2()
	{
		return player2;
	}
	
	public PlayerScreen getPlayer1Screen()
	{
		return player1Screen;
	}
	
	public PlayerScreen getPlayer2Screen()
	{
		return player2Screen;
	}
	
	public State getState()
	{
		return state;
	}
	
	public void setState(State s)
	{
		state = s;
	}
	
	public void update()
	{
		if(!(state instanceof EndGameState))
		{
			state.drawBoard(this);
		}
		//player1 place ships, when placing, only selfGrid needs mouse Listener.
		
	}
	
	public void switchScreen()
	{
		
	}
//	public void setUp()
//	{
//		player1Screen.selfScreenClicked();
//	}
//	
//	public void fire()
//	{
//		player1Screen.attackScreenClicked();
//	}
	
	public void checkWinner()
	{
		
	}
	
//	public void stateChanged(ChangeEvent event)
//	{
//		//no matter what has been changed in the shipBoard, we do the same thing redraw self...
//		System.out.println("model changed...change view...");
//		player1.rebuildFrame("player1", true);
//	}
	
}
